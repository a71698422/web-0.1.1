/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function wasm_main(a: number): void;
export function __wbg_webnes_free(a: number): void;
export function __wbg_get_webnes_audio_sample_rate(a: number): number;
export function __wbg_set_webnes_audio_sample_rate(a: number, b: number): void;
export function webnes_new(a: number, b: number, c: number, d: number): void;
export function webnes_do_frame(a: number): void;
export function webnes_audio_callback(a: number, b: number, c: number, d: number): void;
export function keyboard_status(): number;
export function update_remote_keyboard_state(a: number): void;
export function __wbindgen_malloc(a: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number): number;
export const __wbindgen_export_2: WebAssembly.Table;
export function _dyn_core__ops__function__FnMut__A____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__h2093e33a60176c8d(a: number, b: number, c: number): void;
export function __wbindgen_add_to_stack_pointer(a: number): number;
export function __wbindgen_free(a: number, b: number): void;
export function __wbindgen_exn_store(a: number): void;
