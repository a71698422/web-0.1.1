
export function performance_now() {
  return performance.now();
}